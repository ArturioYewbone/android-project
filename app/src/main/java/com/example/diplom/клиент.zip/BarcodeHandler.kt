package com.example.diplom

class BarcodeHandler {
}